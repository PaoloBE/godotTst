# godot-simple-drag-and-drop
A simple drag and drop system for godot games
